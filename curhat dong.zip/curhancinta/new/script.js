const text = "hi! kamu gimana kabarnya. ceritain ke aku aja!";
let i = 0;

function typeEffect() {
    if (i < text.length) {
        document.getElementById("typing").innerHTML += text.charAt(i);
        i++;
        setTimeout(typeEffect, 50);
    }
}

document.addEventListener("DOMContentLoaded", typeEffect);

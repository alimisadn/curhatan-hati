const textHome = "hi! 🌸 kamu gimana kabarnya. ceritain ke aku aja!";
let j = 0;

function typeEffectHome() {
    if (j < textHome.length) {
        document.getElementById("typing").innerHTML += textHome.charAt(j);
        j++;
        setTimeout(typeEffectHome, 70);
    }
}

document.addEventListener("DOMContentLoaded", typeEffectHome);
